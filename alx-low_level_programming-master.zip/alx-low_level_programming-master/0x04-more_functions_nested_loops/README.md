0. isupper
1. isdigit
2. Collaboration is multiplication
