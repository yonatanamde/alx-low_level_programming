0. Positive anything is better than negative nothing
1. The last digit
2. I sometimes suffer from insomnia. And when I can't fall asleep, I play what I call the alphabet game
3. alphABET
4. When I was having that alphabet soup, I never thought that it would pay off
5. Numbers
6. Numberz
7. Smile in the mirror
8. Hexadecimal
9. Patience, persistence and perspiration make an unbeatable combination for success
10. Inventing is a combination of brains and materials. The more brains you use, the less material you need
11. The success combination in business is: Do what you do better... and: do more of what you do...
12. Software is eating the World

