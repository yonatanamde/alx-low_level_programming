This is a project regarding pointers, string and array
