#include "main.h"
/**
 * _strlen - prints the length of string
 * @s: character
 * Return: integer
 */
int _strlen(char *s)
{
	int i;

	for (i = 0; s[i] != '\0'; i++)
	{
	}

	return (i);
}

