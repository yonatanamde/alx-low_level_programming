#include "main.h"
/**
 * main - generates random passwords
 * 
 * Return: integer
 */
int main()
{
    srand(time(NULL));
    rand(); 

    return (0);
}