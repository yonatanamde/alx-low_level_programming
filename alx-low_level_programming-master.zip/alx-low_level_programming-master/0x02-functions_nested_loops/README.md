0. _putchar
