#include "main.h"
#include <stdio.h>
/**
 * main - prints a word
 * Description: This is a program that prints putchar
 * Return: 0
 */
int main(void)
{
	printf("_putchar\n");
	return (0);
}
