#include <stdio.h>
/**
 * main - prints a long string file
 * Description: this program is a simple outputing a value
 * Return: return zero
 */
int main(void)
{
        printf("with proper grammar, but the outcome is a piece of art,\n");		return (0);
}            
