#include <stdio.h>

/**
 *
 * main - prints string value
 * Description - This program a string value
 * Return: retuns zero
 */
int main(void)
{
		puts("\"Programming is like building a multilingual puzzle");
			return (0);
}


